package com.example.thematicfriend.safety;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface ReportRepository extends JpaRepository<Report,Long> {
    List<Report> findByReporterIdOrderByCreatedAtDesc(Long reporter);
}
